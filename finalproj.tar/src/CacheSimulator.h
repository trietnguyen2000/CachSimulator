/*
	Cache Simulator (Starter Code) by Justin Goins
	Oregon State University
	Spring Term 2021
*/

#ifndef _CACHESIMULATOR_H_
#define _CACHESIMULATOR_H_

#endif //CACHESIMULATOR
