/*
	Cache Simulator (Starter Code) by Justin Goins
	Oregon State University
	Spring Term 2021
*/

#include "CacheController.h"
#include <iostream>
#include <fstream>
#include <regex>
#include <cmath>
#include <cstdlib>

using namespace std;

CacheController::CacheController(CacheInfo ci, string tracefile)
{
	// store the configuration info
	this->ci = ci;
	this->inputFile = tracefile;
	this->outputFile = this->inputFile + ".out";
	// compute the other cache parameters
	this->ci.numByteOffsetBits = log2(ci.blockSize);
	this->ci.numSetIndexBits = log2(ci.numberSets);
	// initialize the counters
	this->globalCycles = 0;
	this->globalHits = 0;
	this->globalMisses = 0;
	this->globalEvictions = 0;

	// Create your cache structure
	// cout << "Sets: " << this->ci.numberSets << endl;
	// cout << "Num blocks: " << this->ci.numByteOffsetBits << endl;
	//Create index, valid, tag, data memory in sets
	//Create each set (array)
	this->ci.sets = new Set[this->ci.numberSets];		   //Make 8 sets
	for (unsigned int i = 0; i < this->ci.numberSets; i++) //Create memory on each block within the set
	{
		// this->ci.sets[i].blocks = new Block[this->ci.associativity]; //Create number of blocks

		this->ci.sets[i].blocks = new Block();			 // Make first block of the set
		this->ci.sets[i].tail = this->ci.sets[i].blocks; // Tail points to first block
		// Initialize the first block
		this->ci.sets[i].tail->valid = false;
		this->ci.sets[i].tail->tag = 0;
		this->ci.sets[i].tail->next = NULL;
		for (unsigned int j = 1; j < this->ci.associativity; j++) // Making N(associativity) blocks in a set
		{
			this->ci.sets[i].tail->next = new Block();			 // Make current block
			this->ci.sets[i].tail = this->ci.sets[i].tail->next; // Set tail to current block
			this->ci.sets[i].tail->valid = false;				 // Initialize current
			this->ci.sets[i].tail->tag = 0;
			this->ci.sets[i].tail->next = NULL;
		}
	}

	// manual test code to see if the cache is behaving properly
	// will need to be changed slightly to match the function prototype
	/*
	cacheAccess(false, 0);
	cacheAccess(false, 128);
	cacheAccess(false, 256);

	cacheAccess(false, 0);
	cacheAccess(false, 128);
	cacheAccess(false, 256);
	*/
}

/*
	Starts reading the tracefile and processing memory operations.
*/
void CacheController::runTracefile()
{
	cout << "Input tracefile: " << inputFile << endl;
	cout << "Output file name: " << outputFile << endl;

	// process each input line
	string line;
	// define regular expressions that are used to locate commands
	regex commentPattern("==.*");
	regex instructionPattern("I .*");
	regex loadPattern(" (L )(.*)(,)([[:digit:]]+)$");
	regex storePattern(" (S )(.*)(,)([[:digit:]]+)$");
	regex modifyPattern(" (M )(.*)(,)([[:digit:]]+)$");

	// open the output file
	ofstream outfile(outputFile);
	// open the output file
	ifstream infile(inputFile);
	// parse each line of the file and look for commands
	while (getline(infile, line))
	{
		// these strings will be used in the file output
		string opString, activityString;
		smatch match; // will eventually hold the hexadecimal address string
		unsigned long int address;
		// create a struct to track cache responses
		CacheResponse response;
		// ignore comments
		if (std::regex_match(line, commentPattern) || std::regex_match(line, instructionPattern))
		{
			// skip over comments and CPU instructions
			continue;
		}
		else if (std::regex_match(line, match, loadPattern))
		{
			cout << "Found a load op!" << endl;
			istringstream hexStream(match.str(2));
			hexStream >> std::hex >> address;
			outfile << match.str(1) << match.str(2) << match.str(3) << match.str(4);
			cacheAccess(&response, false, address, stoi(match.str(4)));
			logEntry(outfile, &response);
		}
		else if (std::regex_match(line, match, storePattern))
		{
			cout << "Found a store op!" << endl;
			istringstream hexStream(match.str(2));
			hexStream >> std::hex >> address;
			outfile << match.str(1) << match.str(2) << match.str(3) << match.str(4);
			cacheAccess(&response, true, address, stoi(match.str(4)));
			logEntry(outfile, &response);
		}
		else if (std::regex_match(line, match, modifyPattern))
		{
			cout << "Found a modify op!" << endl;
			istringstream hexStream(match.str(2));
			// first process the read operation
			hexStream >> std::hex >> address;
			outfile << match.str(1) << match.str(2) << match.str(3) << match.str(4);
			cacheAccess(&response, false, address, stoi(match.str(4)));
			logEntry(outfile, &response);
			outfile << endl;
			// now process the write operation
			hexStream >> std::hex >> address;
			outfile << match.str(1) << match.str(2) << match.str(3) << match.str(4);
			cacheAccess(&response, true, address, stoi(match.str(4)));
			logEntry(outfile, &response);
		}
		else
		{
			throw runtime_error("Encountered unknown line format in tracefile.");
		}
		outfile << endl;
	}
	// add the final cache statistics
	outfile << "Hits: " << globalHits << " Misses: " << globalMisses << " Evictions: " << globalEvictions << endl;
	outfile << "Cycles: " << globalCycles << endl;

	infile.close();
	outfile.close();
}

/*
	Report the results of a memory access operation.
*/
void CacheController::logEntry(ofstream &outfile, CacheResponse *response)
{
	outfile << " " << response->cycles;
	if (response->hits > 0)
		outfile << " hit";
	if (response->misses > 0)
		outfile << " miss";
	if (response->evictions > 0)
		outfile << " eviction";
}

/*
	Calculate the block index and tag for a specified address.
*/
CacheController::AddressInfo CacheController::getAddressInfo(unsigned long int address)
{
	AddressInfo ai;
	// this code should be changed to assign the proper index and tag

	// Convert address (decimal) to binary
	int binary[64];
	int temp = address;
	for (int i = 0; i <= 63; i++)
	{
		binary[i] = temp % 2;
		temp = temp / 2;
	}
	// for (int i = 0; i <= 63; i++)
	// {
	// 	cout << binary[i];
	// }
	// cout << endl;
	// int numBits = ceil(log2(this->ci.associativity)); // # of blockIndexBits

	// Find tag
	ai.tag = address >> (this->ci.numSetIndexBits + this->ci.numByteOffsetBits);

	// Find set index
	// cout << "Offset Bits: " << this->ci.numByteOffsetBits << endl;
	// cout << "Sum: " << this->ci.numSetIndexBits + this->ci.numByteOffsetBits << endl;
	ai.setIndex = 0;
	for (unsigned int i = this->ci.numByteOffsetBits; i < this->ci.numSetIndexBits + this->ci.numByteOffsetBits; i++)
	{
		if (binary[i] == 1)
		{
			ai.setIndex += pow(2, i - this->ci.numByteOffsetBits);
		}
	}

	return ai;
}

/*
	This function allows us to read or write to the cache.
	The read or write is indicated by isWrite.
	address is the initial memory address
	numByte is the number of bytes involved in the access
*/
void CacheController::cacheAccess(CacheResponse *response, bool isWrite, unsigned long int address, int numBytes)
{
	// determine the index and tag
	AddressInfo ai = getAddressInfo(address);

	cout << "\tSet index: " << ai.setIndex << ", tag: " << ai.tag << endl;

	// your code should also calculate the proper number of cycles that were used for the operation
	response->cycles = 0;

	// your code needs to update the global counters that track the number of hits, misses, and evictions
	response->hits = 0;
	response->misses = 0;
	response->evictions = 0;

	Block *temp = this->ci.sets[ai.setIndex].blocks; // Start at head
	int status = 0;
	while (temp != NULL) // Traverse through the list to look for value
	{
		if (temp->tag == ai.tag && temp->valid == true)
		{ // Hit
			status = 1;
			break;
		}
		else
		{
			status = 2;
		}
		temp = temp->next;
	}
	// cout << "Status " << status << endl;
	switch (status)
	{
	case 1:				  // Hit
		if (isWrite == 0) // Read
		{
			// Increment hit
			response->hits++;
			globalHits++;
			// Increment cache cycle
			response->cycles = this->ci.cacheAccessCycles + log(this->ci.blockSize) / log(numBytes);
			globalCycles += response->cycles;
		}
		else
		{
			response->hits++;
			globalHits++;

			response->cycles = this->ci.cacheAccessCycles + this->ci.memoryAccessCycles + 2 * log(this->ci.blockSize) / log(numBytes);
			globalCycles += response->cycles;
		}
		break;
	case 2:
		// Increment miss
		response->misses++;
		globalMisses++;
		// Check for empty slots in list
		temp = this->ci.sets[ai.setIndex].blocks;
		while (this->ci.sets[ai.setIndex].blocks != NULL)
		{
			if (this->ci.sets[ai.setIndex].blocks->valid == false) // Empty
			{
				status = 4;
				// Add value to the end
				this->ci.sets[ai.setIndex].blocks->tag = ai.tag;
				this->ci.sets[ai.setIndex].blocks->valid = true;
				break;
			}
			else // Full
			{
				status = 5;
			}
			this->ci.sets[ai.setIndex].blocks = this->ci.sets[ai.setIndex].blocks->next;
		}
		this->ci.sets[ai.setIndex].blocks = temp;
		if (status == 5)
		{
			if (this->ci.rp == ReplacementPolicy::Random)
			{
				rand_replacement(ai);
			}
			else if (this->ci.rp == ReplacementPolicy::LRU)
			{
				LRU_replacement(ai);
			}
			// Increment eviction
			response->evictions++;
			globalEvictions++;
		}
		// Increment cycles
		response->cycles = this->ci.cacheAccessCycles + this->ci.memoryAccessCycles + 2 * log(this->ci.blockSize) / log(numBytes);
		globalCycles += response->cycles;
		break;
	}

	if (response->hits > 0)
		cout
			<< "Operation at address " << std::hex << address << " caused " << response->hits << " hit(s)." << std::dec << endl;
	if (response->misses > 0)
		cout << "Operation at address " << std::hex << address << " caused " << response->misses << " miss(es)." << std::dec << endl;

	cout << "-----------------------------------------" << endl;

	return;
}

/*
	Compute the LRU replacement policy
*/
void CacheController::LRU_replacement(AddressInfo ai)
{
	// New block
	this->ci.sets[ai.setIndex].tail->next = new Block; // Make new block
	this->ci.sets[ai.setIndex].tail = this->ci.sets[ai.setIndex].tail->next;
	this->ci.sets[ai.setIndex].tail->tag = ai.tag;
	this->ci.sets[ai.setIndex].tail->valid = true;
	Block *temp = this->ci.sets[ai.setIndex].blocks->next; // Set temp to next oldest block
	delete this->ci.sets[ai.setIndex].blocks;			   // Delete oldest block
	this->ci.sets[ai.setIndex].blocks = temp;			   // Set head to the next oldest
	this->ci.sets[ai.setIndex].tail->next = NULL;
}

/*
	Compute the Random replacement policy
*/
void CacheController::rand_replacement(AddressInfo ai)
{
	int index = rand() % this->ci.associativity;
	cout << "Rand: " << index << endl;

	// Start at the beginning
	Block *temp = this->ci.sets[ai.setIndex].blocks; // Point temp to head
	// Traverse through the amount of index
	for (int i = 0; i < index; i++)
	{
		this->ci.sets[ai.setIndex].blocks = this->ci.sets[ai.setIndex].blocks->next;
	}
	this->ci.sets[ai.setIndex].blocks->tag = ai.tag; // Copy tag
	this->ci.sets[ai.setIndex].blocks->valid = true; // Copy valid
	this->ci.sets[ai.setIndex].blocks = temp;		 // Point head back to temp
}

/*
	Destructor
*/
CacheController::~CacheController()
{
	Block *temp = NULL;
	for (unsigned int i = 0; i < this->ci.numberSets; i++) //Create memory on each block within the set
	{
		temp = this->ci.sets[i].blocks; // Start temp at head
		while (temp != NULL)
		{
			temp = this->ci.sets[i].blocks->next; // Point temp to the next block
			delete this->ci.sets[i].blocks;		  // Delete current block
			this->ci.sets[i].blocks = temp;		  // Set next block to current block
		}
		this->ci.sets[i].blocks = NULL;
	}
	delete[] this->ci.sets;
}